class TipoRecompensa {}

TipoRecompensa.VER_TODO 			  = 0;
TipoRecompensa.INTOCABLE 			  = 1;
TipoRecompensa.ELIMINAR_OBSTACULOS = 2;
TipoRecompensa.VIDA_EXTRA 			  = 3;

TipoRecompensa.NUM_TIPOS 			  = 4;

export { TipoRecompensa };
